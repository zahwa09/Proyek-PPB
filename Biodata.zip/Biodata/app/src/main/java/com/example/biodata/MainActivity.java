package com.example.biodata;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class MainActivity extends AppCompatActivity {

    Button btnpanggil,btngmail, btnalamat

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnpanggil = findViewById(R.id.Btn_panggil);
        btnpanggil = findViewById(R.id.Btn_gmail);
        btnpanggil = findViewById(R.id.Btn_alamat);

        btnpanggil.setOnClickListener(new View.OnClickListener(){
            @override
            public void onClick(View V){
                String nomor="0812367890";
                Intent memanggil = new Intent(Intent.ACTION_DIAL);
                memanggil.setData(Uri.fromParts(scheme "Tel",nomor, fragment: null));
                startAvtivity(memanggil);
            }
        });

        btngmail.setOnClickListener(new View.OnClickListener(){
            @override
            public void onClick(View V){
                Intent gmail = new Intent(Intent.ACTION_SEND);
                emailIntent.setType("message/rtc822");
                String[] to={"Zahwa@gmail.com"};
                emailIntent.putExtra(Intent.EXTRA_EMAIL, to);
                startAvtivity(emailIntent);
            }
        });

        btnalamat.setOnClickListener(new View.OnClickListener(){
            @override
            public void onClick(View V){
                Intent intent,chooser;
                Intent = new Intent(Intent.ACTION_View);
                Intent.setData(Uri.parse(memanggil.setData(https://goo.gl/maps/twvD4n9aN4Mv4WeR7));
                Chooser = Intent.CreateChooser(intent, "Launch Map");
                startAvtivity(Chooseer);
            }
        });
    }
}