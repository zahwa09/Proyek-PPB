package com.dc024.ppb_menumakanan;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

public class DetailMenuMakananActivity extends AppCompatActivity {

    private ImageView ivImage;
    private TextView tvNamaMenu, tvAsalMenu, tvHargaMenu,tvDescMenu;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail_menu_makanan);

        ivImage = findViewById(R.id.ivImage);
        tvNamaMenu = findViewById(R.id.tvNamaMenu);
        tvAsalMenu = findViewById(R.id.tvAsalMenu);
        tvHargaMenu = findViewById(R.id.tvHargaMenu);
        tvDescMenu = findViewById(R.id.tvDescMenu);

        if(getIntent().getExtras()!=null) {
            Bundle bundle = getIntent().getExtras();
            ivImage.setImageResource(bundle.getInt("image"));
            tvNamaMenu.setText(bundle.getString("nama"));
            tvAsalMenu.setText(bundle.getString("asal"));
            tvHargaMenu.setText(bundle.getString("harga"));
            tvDescMenu.setText(bundle.getString("desc"));
        }
    }
}